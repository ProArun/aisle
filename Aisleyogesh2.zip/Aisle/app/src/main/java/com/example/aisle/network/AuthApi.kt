package com.example.aisle.network

//import com.example.aisle.network.models.GetOtpResponse
import com.example.aisle.network.models.GetOtpResponse
import com.example.aisle.network.models.Mobile
import com.example.aisle.network.models.Otp
import okhttp3.ResponseBody
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST

interface AuthApi {

    @POST("phone_number_login")
    fun getOTP(
        @Body body: Mobile
    ): ResponseBody
   //): GetOtpResponse
   // ): Boolean

    @POST("verify_otp")
    fun verifyOtp(
        @Body body: Otp
    ): ResponseBody

    @GET("test_profile_list")
    fun getUser(
        @Header("Authorization") authToken: String
    ): ResponseBody

}