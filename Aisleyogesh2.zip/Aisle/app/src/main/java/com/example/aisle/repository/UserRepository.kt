package com.example.aisle.repository

import com.example.aisle.network.AuthApi
import com.example.aisle.network.models.Mobile
import com.example.aisle.network.models.Otp

class UserRepository(private val api: AuthApi) : BaseRepository() {
    suspend fun getUser(
        authToken:String
    ) = safeApiCall {
        api.getUser(authToken)
    }
}