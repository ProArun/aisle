package com.example.aisle.network.models

import com.google.gson.annotations.SerializedName

data class GetOtpResponse(
    @SerializedName("status") var status: Boolean? = null
)