package com.example.aisle.viewModels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.aisle.network.ApiResponse
import com.example.aisle.network.models.GetOtpResponse
import com.example.aisle.network.models.Mobile
import com.example.aisle.repository.AuthRepository
import kotlinx.coroutines.launch
import okhttp3.ResponseBody

//import okhttp3.ResponseBody

class AuthViewModel(
    private val repository: AuthRepository
) : ViewModel() {

     //private val _getOtpResponse: MutableLiveData<ApiResponse<GetOtpResponse>> = MutableLiveData()
    // private val _getOtpResponse: MutableLiveData<ApiResponse<Boolean>> = MutableLiveData()
    private val _getOtpResponse: MutableLiveData<ApiResponse<ResponseBody>> = MutableLiveData()

    //val getOtpResponse: LiveData<ApiResponse<GetOtpResponse>>
    //val getOtpResponse: LiveData<ApiResponse<Boolean>>
    val getOtpResponse: LiveData<ApiResponse<ResponseBody>>
        get() = _getOtpResponse

    fun getOTP(
        mobile: Mobile
    ) = viewModelScope.launch {
        _getOtpResponse.value = repository.getOTP(mobile)
    }

}