package com.example.aisle.viewModels

import androidx.lifecycle.ViewModel
import com.example.aisle.repository.UserRepository

class UserViewModel(
    private val repository: UserRepository
): ViewModel()  {

}