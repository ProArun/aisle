package com.example.aisle.activites

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.example.aisle.R

class OtpActivity : AppCompatActivity() {
    private lateinit var countDownTimerText: TextView
    private lateinit var resendOtpText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_otp)
        val continueButton: Button = findViewById(R.id.continue_otp_button)
        countDownTimerText = findViewById(R.id.count_down_timer_text)
        resendOtpText = findViewById(R.id.resend_otp_text)

        timer.start()
        continueButton.setOnClickListener(View.OnClickListener {
            if (countDownTimerText.text.toString() == "00:00") {
                Toast.makeText(this, "Time Out", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent);
                finish()
            }
        })
        resendOtpText.setOnClickListener(View.OnClickListener {
            timer.start()
            resendOtpText.visibility = View.GONE
        })
    }

    val timer = object : CountDownTimer(6000, 1000) {
        override fun onTick(millisUntilFinished: Long) {
            var remTime: Long = millisUntilFinished.div(1000)
            if (remTime > 10) {
                countDownTimerText.text = "00:$remTime"
            } else {
                countDownTimerText.text = "00:0$remTime"
            }
        }

        override fun onFinish() {
            countDownTimerText.text = "00:00"
            resendOtpText.visibility = View.VISIBLE
        }
    }


}