package com.example.aisle.fragments

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.aisle.R
import com.example.aisle.activites.MainActivity
import com.example.aisle.activites.MobileNumberActivity
import com.example.aisle.adapters.CustomAdapter
import com.example.aisle.models.ProfileOfUsers
import java.util.ArrayList


class DiscoverFragment : Fragment() {
    lateinit var courseGRV: RecyclerView
    lateinit var courseList: List<ProfileOfUsers>
    lateinit var logOutImg: ImageView
    lateinit var upgradeButton: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val root = inflater.inflate(R.layout.fragment_discover, container, false)
        // return inflater.inflate(R.layout.fragment_discover, container, false)
        courseGRV = root.findViewById(R.id.idGRV)
        logOutImg = root.findViewById(R.id.log_out_img)
        upgradeButton = root.findViewById(R.id.upgrade_button)
        //courseGRV.setHasFixedSize(false);
        courseList = ArrayList<ProfileOfUsers>()

        // on below line we are adding data to
        // our course list with image and course name.
        //courseList = courseList + ProfileOfUsers("Arun", R.drawable.visa2)
        courseList = courseList + ProfileOfUsers("Arun", "")
        courseList = courseList + ProfileOfUsers("Arvind", "")
        courseList = courseList + ProfileOfUsers("Prem", "")
        courseList = courseList + ProfileOfUsers("Khushboo", "")
        courseList = courseList + ProfileOfUsers("Ram Naresh", "")

        courseGRV.apply {
            setHasFixedSize(true)
            layoutManager = GridLayoutManager(context, 2)
            adapter = CustomAdapter(courseList)
        }
        val sharedPreference = requireContext().getSharedPreferences("AISLE_PREFERENCE_DB", Context.MODE_PRIVATE)
        val editor = sharedPreference.edit()
        editor.putString("TOKEN", "1234")
        editor.apply()
        logOutImg.setOnClickListener(View.OnClickListener {
            editor.remove("TOKEN")
            editor.apply()
            Toast.makeText(
                requireContext(),
                "You are successfully logout\nThanks for using Aisle",
                Toast.LENGTH_SHORT
            ).show()
            Handler().postDelayed({
//                activity?.moveTaskToBack(true);
//                activity?.finish()
//                val intent = requireActivity()?.Intent(this, MainActivity::class.java)
//                startActivity(intent);
//                finish()
                activity?.let{
                    val intent = Intent (it, MobileNumberActivity::class.java)
                    it.startActivity(intent)
                    it.finishAffinity()
                }
            }, 3000)
        })

        upgradeButton.setOnClickListener(View.OnClickListener {
            Toast.makeText(requireContext(), "Thank you for showing interest\n Our team will connect you soon", Toast.LENGTH_SHORT).show()
        })
        return root;
    }


}