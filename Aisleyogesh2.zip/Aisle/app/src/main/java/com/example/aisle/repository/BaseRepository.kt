package com.example.aisle.repository

import android.content.ContentValues.TAG
import android.util.Log
import com.example.aisle.network.ApiResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.HttpException

abstract class BaseRepository {

    suspend fun <T> safeApiCall(
        apiCall: suspend () -> T
    ): ApiResponse<T> {

        return withContext(Dispatchers.IO) {
            try {
                Log.d(TAG, "safeApiCall: before  apicall")
                val res = apiCall.invoke()
                Log.d(TAG, "safeApiCall: $res of apicall")
                ApiResponse.Success(res)
                //ApiResponse.Success(apiCall.invoke())
            } catch (throwable: Throwable) {
                when (throwable) {
                    is HttpException -> {
                        ApiResponse.Failure(
                            false,
                            throwable.code(),
                            throwable.response()?.errorBody()
                        )
                    }
                    else -> {
                        //ApiResponse.Failure(true, null, null)
                        Log.d(
                            TAG,
                            "safeApiCall: \nmessage:- " + throwable.message.toString() + " \ncouse:- " + throwable.cause.toString()
                        )
                        ApiResponse.Failure(true, null, null)
                    }
                }
            }
        }
    }
}