package com.example.aisle.network.models

import com.google.gson.annotations.SerializedName

data class Mobile (

    @SerializedName("number" ) var number : String? = null

)