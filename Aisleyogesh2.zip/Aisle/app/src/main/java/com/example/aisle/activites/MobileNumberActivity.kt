package com.example.aisle.activites

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.aisle.R
import com.example.aisle.databinding.ActivityMobileNumberBinding
import com.example.aisle.network.ApiResponse
import com.example.aisle.network.AuthApi
import com.example.aisle.network.RemoteDataSource
import com.example.aisle.network.models.Mobile
import com.example.aisle.repository.AuthRepository
import com.example.aisle.utils.Utils.isValidPhoneNumber
import com.example.aisle.viewModels.AuthViewModel
import com.example.aisle.viewModels.ViewModelFactory

class MobileNumberActivity : AppCompatActivity() {
    private val TAG: String = "SplashActivity";
    protected lateinit var binding: ActivityMobileNumberBinding
    protected lateinit var viewModel: AuthViewModel
    protected val remoteDataSource = RemoteDataSource()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //view
        binding = ActivityMobileNumberBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        //repo
        val authRepository = AuthRepository(remoteDataSource.buildApi(AuthApi::class.java))

        //viewModel
        val factory = ViewModelFactory(authRepository)
        viewModel = ViewModelProvider(this, factory).get(AuthViewModel::class.java)

        viewModel.getOtpResponse.observe(this, Observer {
            when (it) {
                is ApiResponse.Success -> {
                    Log.d(TAG, "onCreate: onSuccess :- ${it.toString()}")
                    Toast.makeText(this, it.toString(), Toast.LENGTH_SHORT).show()
//                    val intent = Intent(this, OtpActivity::class.java)
//                    startActivity(intent);
                }
                is ApiResponse.Failure -> {
                    Log.d(TAG, "onCreate: onFailure :- " + it.errorBody.toString() + it.errorCode.toString() + it.isNetworkError.toString())
                    // Toast.makeText(this, "Login failure", Toast.LENGTH_SHORT).show()
                    Toast.makeText(
                        this,
                        it.errorBody.toString() + it.errorCode.toString() + it.isNetworkError.toString(),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        })

        binding.continueButton.setOnClickListener(View.OnClickListener {
            val mobileNumber = binding.enterPhoneEditText.text.toString()
            if (mobileNumber.length < 10) {
                Log.d(TAG, "onCreate: Mobile number shouldn't be less than 10 digits!!")

                Toast.makeText(
                    this,
                    "Mobile number shouldn't be less than 10 digits!!",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                if (mobileNumber.isValidPhoneNumber()) {
                    ///todo do network call
                   // viewModel.getOTP(Mobile("+91$mobileNumber"))
                    val intent = Intent(this, OtpActivity::class.java)
                    startActivity(intent);

                } else {
                    Log.d(TAG, "onCreate: Please Enter a valid Number!!")
                    Toast.makeText(this, "Please Enter a valid Number!!", Toast.LENGTH_SHORT).show()
                }

            }

        })
    }
}