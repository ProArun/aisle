package com.example.aisle.repository

import com.example.aisle.network.AuthApi
import com.example.aisle.network.models.Mobile
import com.example.aisle.network.models.Otp

class AuthRepository(private val api: AuthApi) : BaseRepository() {

    suspend fun getOTP(
        mobile: Mobile
    ) = safeApiCall {
        api.getOTP(mobile)
    }

    suspend fun verifyOtp(
        otp: Otp
    ) = safeApiCall {
        api.verifyOtp(otp)
    }

}